import { InfluxDB, Point } from '@influxdata/influxdb-client';

const token = 'GDvvr1RMzHwHaQOxLa67CXEjIALC-fnZ28p5G6TNYZ5b1W3_lsDmeb1iSfYAAQdA7oUqIsfMrSnxUGupEs8mgA=='; // Ganti dengan token Anda
const org = 'eone';
const bucket = 'machine_downtime';

const influxDB = new InfluxDB({ url: 'http://localhost:8086', token });
const writeApi = influxDB.getWriteApi(org, bucket);

export default async function CreateDowntimeLog(fastify, opts) {
  const dbClient = await fastify.pg.connect();

  const machineEvents = {}; // Menyimpan semua events (downtime dan gap)

  fastify.post('/api/inject-event', async (request, reply) => {
    const injectPromises = request.body.map(async ({ machineId }) => {
      try {
        const lastrunningtime = await getlastrunningtime(machineId);
        await logInjectData(machineId);
        await updateLastRunningTime(machineId);
        await checkAndLogDowntime(machineId, lastrunningtime);
        fastify.log.info(`Successfully injected event for machine ${machineId} at ${new Date().toISOString()}`);
      } catch (error) {
        fastify.log.error(`Error processing machine ${machineId}:`, error);
      }
    });

    await Promise.all(injectPromises);
    
    reply.send({ message: 'Inject data received and processed' });
  });

  fastify.get('/api/events/:machineId', async (request, reply) => {
    const { machineId } = request.params;
    const events = (machineEvents[machineId] || []).sort((a, b) => a.startTime - b.startTime);
    reply.send(events);
  });

  const getlastrunningtime = async (machineId) => {
    try {
      const result = await dbClient.query('SELECT last_running_time FROM machines WHERE machine_id = $1', [machineId]);
      if (result.rows.length > 0) {
        return new Date(result.rows[0].lastrunningtime); 
      }
      return null;
    } catch (error) {
      fastify.log.error('Error fetching last running date:', error);
      return null; 
    }
  };

  const logInjectData = async (machineId) => {
    const currentTime = new Date();

    const point = new Point('machine_log')
      .tag('machine_id', machineId)
      .floatField('status', 1) // Misalnya, field status dengan nilai 1
      .timestamp(currentTime);

      console.log('Point to write:', point);

    try {
      await writeApi.writePoint(point);
      await writeApi.flush(); // Pastikan data tertulis
      fastify.log.info(`Successfully saved machine log for machine ${machineId} at ${currentTime.toISOString()}`);
    } catch (error) {
      fastify.log.error(`Error saving machine log for machine ${machineId}:`, error);
    }
  };

  const updateLastRunningTime = async (machineId) => {
    const currentTime = new Date();
    try {
      await dbClient.query('UPDATE mes.machines SET last_running_time = $1 WHERE machine_id = $2', [currentTime, machineId]);
      fastify.log.info(`Successfully updated last running time for machine ${machineId}`);
    } catch (error) {
      fastify.log.error(`Error updating last running time for machine ${machineId}:`, error);
    }
  };
  
  const checkAndLogDowntime = async (machineId, lastrunningtime) => {
    const currentTime = new Date();

    if (lastrunningtime) {
      const downtimeDuration = (currentTime - lastrunningtime) / 1000; // in seconds

      if (downtimeDuration > 300) {
        // Log downtime
        const downtimeStartTime = lastrunningtime; // Start time from last running date
        const downtimeEndTime = currentTime; // End time now

        await logDowntime(machineId, downtimeStartTime, downtimeEndTime);
        await logGap(machineId, downtimeEndTime);
      }
    }
  };

  const logDowntime = async (machineId, startTime, endTime) => {
    const point = new Point('downtime_events')
      .tag('machine_id', machineId)
      .intField('start_time', Math.floor(startTime.getTime() / 1000)) // Store as seconds
      .intField('end_time', Math.floor(endTime.getTime() / 1000)) // Store as seconds
      .floatField('duration', (endTime - startTime) / 1000); // Duration in seconds

    if (!machineEvents[machineId]) {
      machineEvents[machineId] = [];
    }
    machineEvents[machineId].push({ type: 'downtime', startTime, endTime });

    try {
      await writeApi.writePoint(point);
      await writeApi.flush(); // Pastikan data tertulis
      fastify.log.info(`Successfully logged downtime event for machine ${machineId} from ${startTime.toISOString()} to ${endTime.toISOString()}`);
    } catch (error) {
      fastify.log.error(`Error logging downtime event for machine ${machineId}:`, error);
    }
  };

  const logGap = async (machineId, lastDowntimeEndTime) => {
    const currentTime = new Date();

    // Ambil downtime terakhir yang tercatat
    const downtimes = machineEvents[machineId] || [];
    const lastDowntime = downtimes[downtimes.length - 1];

    if (lastDowntime) {
      const gapStartTime = lastDowntime.endTime; // Akhir downtime terakhir
      const gapEndTime = lastDowntimeEndTime; // Waktu sekarang

      // Cek apakah ada gap
      if (gapStartTime < gapEndTime) {
        const point = new Point('gap_events')
          .tag('machine_id', machineId)
          .intField('start_time', Math.floor(gapStartTime.getTime() / 1000)) // Store as seconds
          .intField('end_time', Math.floor(gapEndTime.getTime() / 1000)) // Store as seconds
          .floatField('duration', (gapEndTime - gapStartTime) / 1000); // Duration in seconds

        try {
          await writeApi.writePoint(point);
          await writeApi.flush(); // Pastikan data tertulis
          fastify.log.info(`Successfully logged gap event for machine ${machineId} from ${gapStartTime.toISOString()} to ${gapEndTime.toISOString()}`);
          machineEvents[machineId].push({ type: 'gap', startTime: gapStartTime, endTime: gapEndTime });
        } catch (error) {
          fastify.log.error(`Error logging gap event for machine ${machineId}:`, error);
        }
      }
    }
  };

  const machineIds = [3, 4]; // machine 110 dan machine 53
  setInterval(async () => {
    for (const machineId of machineIds) {
      await fastify.inject({
        method: 'POST',
        url: '/api/inject-event',
        payload: [{ machineId }],
      });
      console.log(`Injected event for ${machineId} at ${new Date().toISOString()}`);
    }
  }, 15000); // Setiap 15 detik
}
