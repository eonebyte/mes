import { InfluxDB } from '@influxdata/influxdb-client';

const token = 'GDvvr1RMzHwHaQOxLa67CXEjIALC-fnZ28p5G6TNYZ5b1W3_lsDmeb1iSfYAAQdA7oUqIsfMrSnxUGupEs8mgA=='; // Ganti dengan token Anda
const org = 'eone';
const bucket = 'machine_downtime';

const influxDB = new InfluxDB({ url: 'http://localhost:8086', token });

// Fungsi plugin Fastify
export default async function ReadDowntimeLog(fastify, opts) {
  fastify.get('/downtime-events', async (request, reply) => {
    try {
      const queryApi = influxDB.getQueryApi(org);
      const query = `
        from(bucket: "${bucket}") 
        |> range(start: -5m) // Ambil data 5 menit terakhir
        |> filter(fn: (r) => r._measurement == "downtime_events")
        |> sort(columns: ["_time"], desc: true) // Data terbaru di atas
      `;

      const results = await queryApi.collectRows(query);

      // Mengubah format hasil menjadi { start, end } 
      const formattedResults = results.map(row => ({
        start: new Date(row._time).toISOString(), // Ubah menjadi format ISO string
        end: new Date(row._time + row.duration * 1000).toISOString(), // Tambahkan durasi untuk mendapatkan end time
        machine_id: row.machine_id,
        duration: row.duration,
      }));

      reply.send(formattedResults);
    } catch (error) {
      console.error('Error querying InfluxDB:', error);
      reply.status(500).send({ error: 'Internal Server Error' });
    }
  });
}
